/* global document */
jQuery(document).ready(function() {

	/***
	Adding slideshow.
	***/

	/* Calling flexslider() function, initializing slideshow. */
	jQuery('#slideshow').flexslider({
		controlNav: false
	});

});
<div class="no-access">
    <?php echo '***************'; ?>
    <div class="no-access-icon">
        <i class="fa fa-exclamation-circle fa-lg"></i>
        <div class="no-access-notice">
            <?php echo __('To view this information you need to','metrodir'); ?> <a href="<?php echo home_url('/submit-listing/'); ?>"><?php echo __('subscribe or upgrade your Account','metrodir'); ?></a>
        </div>
        <div class="no-access-triangle"></div>
        <div class="no-access-viewer"></div>
    </div>
</div>
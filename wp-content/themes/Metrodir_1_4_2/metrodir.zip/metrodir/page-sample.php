<?php
/*
Template Name: Sample page
*/
?>

<?php get_template_part('page');
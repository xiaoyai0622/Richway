<?php

$tab_custom_content =  $custom[$shortname . '_custom_tabs_content'][0];

echo $tab_custom_content;



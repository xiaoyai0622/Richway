<!-- Script Share Button Social Network --><script>
    function metrodir_share_FB() {
        window.open(
            'https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(location.href)+'&t='+encodeURIComponent(document.title),
            'facebook-share-dialog',
            'width=626,height=436');
        return false;
    }
    function metrodir_share_GP() {
        window.open(
            'https://plus.google.com/share?url='+encodeURIComponent(location.href),
            'width=626,height=436');
        return false;
    }
    function metrodir_share_TW() {
        window.open(
            'http://twitter.com/share?url='+encodeURIComponent(location.href),
            'width=626,height=436');
        return false;
    }
    function metrodir_share_LI() {
        window.open(
            'http://www.linkedin.com/shareArticle?url='+encodeURIComponent(location.href),
            'width=626,height=436');
        return false;
    }
    function metrodir_share_PI() {
        window.open(
            'http://pinterest.com/pin/create/button/?url='+encodeURIComponent(location.href),
            'width=626,height=436');
        return false;
    }
    function metrodir_share_DB() {
        window.open(
            'http://dribbble.com/',
            'width=626,height=436');
        return false;
    }
</script><!-- /Script Share Button Social Network -->